#' The adult data set
#'
#' data
#' 
#' @name adult
NULL
