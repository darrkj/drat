#' CADE: A package for using the cade algorithm to find outliers.
#'
#' The CADE package provides functions to find outliers and make uniform 
#' distributions of each varaible type.
#' 
#' @docType package
#' @name CADE
NULL
